from deep_translator import GoogleTranslator

def translate_transcript(transcript_data: list, target_lang: str = "es") -> list:
    """
    Translates transcript segments by joining all lines into a single request
    to completely prevent Google Translate rate limiting and 500 errors.
    """
    if not transcript_data:
        return []

    # 1. Join all text lines using a unique separator
    # We use ' ||| ' so Google treats it as one text block and doesn't break formatting
    separator = " ||| "
    original_texts = [seg["text"].strip() for seg in transcript_data]
    combined_text = separator.join(original_texts)

    try:
        # 2. Make ONE SINGLE API call
        translator = GoogleTranslator(source="auto", target=target_lang)
        translated_combined = translator.translate(combined_text)

        # 3. Split the result back into individual segment strings
        translated_texts = translated_combined.split("|||")

        # Clean up any residual spacing
        translated_texts = [t.strip() for t in translated_texts]

        # Safety check: if splitting mismatched the line count, fallback gracefully
        if len(translated_texts) != len(transcript_data):
            print("[!] Warning: Split count mismatch. Cleaning up list length...")
            while len(translated_texts) < len(transcript_data):
                translated_texts.append(transcript_data[len(translated_texts)]["text"])

    except Exception as e:
        print(f"[!] Translation API error: {e}")
        # Fallback to original text if the request fails completely
        translated_texts = original_texts

    # 4. Build output list with timing metrics
    translated_transcript = []

    for idx, segment in enumerate(transcript_data):
        original_text = segment["text"].strip()
        translated_text = translated_texts[idx]
        start_time = segment["start"]
        end_time = segment["end"]
        duration = round(end_time - start_time, 2)

        char_count = len(translated_text)
        max_recommended_chars = int(duration * 17)
        is_too_long = char_count > max_recommended_chars if duration > 0 else False

        translated_transcript.append({
            "start": start_time,
            "end": end_time,
            "duration": duration,
            "original_text": original_text,
            "translated_text": translated_text,
            "char_count": char_count,
            "is_too_long": is_too_long
        })

    return translated_transcript