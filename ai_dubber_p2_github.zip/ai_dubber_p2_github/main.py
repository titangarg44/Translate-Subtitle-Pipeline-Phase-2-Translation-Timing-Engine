import os
import shutil
from typing import List

from fastapi import FastAPI, File, HTTPException, Query, UploadFile
from fastapi.responses import JSONResponse
from pydantic import BaseModel

from core import extract_audio, generate_srt, transcribe_audio
from translator import translate_transcript

app = FastAPI(
    title="AI Dubbing Pipeline - Phase 2",
    description="API endpoint for video transcription, cross-lingual translation, and timing analysis.",
    version="2.0.0"
)

# Request schema for standalone translation
class Segment(BaseModel):
    start: float
    end: float
    text: str

class TranslationRequest(BaseModel):
    target_lang: str = "es"
    segments: List[Segment]


@app.post("/transcribe", summary="Phase 1: Process Video to Transcript")
async def process_video(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(('.mp4', '.mkv', '.mov', '.avi')):
        raise HTTPException(status_code=400, detail="Invalid file type.")

    temp_video_path = f"temp_{file.filename}"
    try:
        with open(temp_video_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        audio_path = extract_audio(temp_video_path)
        transcript_data = transcribe_audio(audio_path)
        srt_path = generate_srt(transcript_data, f"{file.filename}.srt")
        
        if os.path.exists(temp_video_path):
            os.remove(temp_video_path)
        if os.path.exists(audio_path):
            os.remove(audio_path)

        return JSONResponse(content={
            "filename": file.filename,
            "status": "success",
            "srt_file": srt_path,
            "data": transcript_data
        })
    except Exception as e:
        if os.path.exists(temp_video_path):
            os.remove(temp_video_path)
        if 'audio_path' in locals() and os.path.exists(audio_path):
            os.remove(audio_path)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/translate", summary="Phase 2: Translate JSON Transcript")
async def translate_segments(payload: TranslationRequest):
    """
    Translates raw JSON transcript segments into target language with timing metrics.
    """
    try:
        raw_segments = [seg.dict() for seg in payload.segments]
        translated_data = translate_transcript(raw_segments, target_lang=payload.target_lang)
        return JSONResponse(content={
            "target_lang": payload.target_lang,
            "data": translated_data
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/transcribe-and-translate", summary="Phase 1 & 2: Combined Universal Video Pipeline")
async def process_video_and_translate(file: UploadFile = File(...), target_lang: str = Query("hi", description="Target ISO language code, e.g., en, hi, es, lv, pa")):
    """
    Accepts ANY video upload and generates localized subtitles for ANY target language.
    """
    temp_video = f"temp_{file.filename}"
    temp_audio = f"temp_{file.filename}.wav"
    
    try:
        # Save uploaded file
        with open(temp_video, "wb") as buffer:
            buffer.write(await file.read())
            
        # Step 1: Extract Audio
        extract_audio(temp_video, temp_audio)
        
        # Step 2: Transcribe with Whisper (Auto-detects spoken language)
        raw_transcript, source_lang = transcribe_audio(temp_audio, target_lang=target_lang)
        
        # Step 3: Dynamic Translation Routing
        # If source language matches target language (or target is 'en' via Whisper translate task), no extra translation needed
        if source_lang == target_lang or target_lang == "en":
            final_transcript = []
            for seg in raw_transcript:
                duration = round(seg["end"] - seg["start"], 2)
                char_count = len(seg["text"])
                final_transcript.append({
                    "start": seg["start"],
                    "end": seg["end"],
                    "duration": duration,
                    "original_text": seg["text"],
                    "translated_text": seg["text"],
                    "text": seg["text"],  # Backward compatibility for generate_srt
                    "char_count": char_count,
                    "is_too_long": char_count > int(duration * 17)
                })
        else:
            # Pass to deep-translator for cross-language translation (e.g., Hindi->Latvian, French->Punjabi)
            final_transcript = translate_transcript(raw_transcript, target_lang=target_lang)
            
        # Step 4: Export SRT Subtitles
        srt_filename = f"{file.filename}_{target_lang}.srt"
        generate_srt(final_transcript, srt_filename)
        
        return {
            "filename": file.filename,
            "detected_source_lang": source_lang,
            "target_lang": target_lang,
            "translated_srt_file": srt_filename,
            "data": final_transcript
        }
        
    finally:
        # Cleanup temporary files
        if os.path.exists(temp_video):
            os.remove(temp_video)
        if os.path.exists(temp_audio):
            os.remove(temp_audio)
            
if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True) 
"""
from tts_engine import synthesize_and_fit_transcript

@app.post("/synthesize", tags=["Phase 3: TTS Synthesis"])
async def synthesize_speech(payload: TranslationRequest):

    Synthesizes speech audio clips from translated segments with automatic speed adjustment.

    try:
        # Convert Pydantic objects to dict list
        transcript_data = [seg.dict() for seg in payload.segments]
        audio_segments = synthesize_and_fit_transcript(transcript_data, payload.target_lang)
        
        return JSONResponse(content={
            "target_lang": payload.target_lang,
            "total_segments": len(audio_segments),
            "segments": audio_segments
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))
""" 