from fastapi import FastAPI, UploadFile, File, HTTPException, Query
from fastapi.responses import JSONResponse
from pydantic import BaseModel
from typing import List
import shutil
import os

from core import extract_audio, transcribe_audio, generate_srt
from translator import translate_transcript

app = FastAPI(
    title="AI Dubbing Pipeline - Phase 2",
    description="API endpoint for video transcription, cross-lingual translation, and timing analysis.",
    version="2.0.0"
)

# Request schema for standalone translation
class Segment(BaseModel):
    start: float
    end: float
    text: str

class TranslationRequest(BaseModel):
    target_lang: str = "es"
    segments: List[Segment]


@app.post("/transcribe", summary="Phase 1: Process Video to Transcript")
async def process_video(file: UploadFile = File(...)):
    if not file.filename.lower().endswith(('.mp4', '.mkv', '.mov', '.avi')):
        raise HTTPException(status_code=400, detail="Invalid file type.")

    temp_video_path = f"temp_{file.filename}"
    try:
        with open(temp_video_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        audio_path = extract_audio(temp_video_path)
        transcript_data = transcribe_audio(audio_path)
        srt_path = generate_srt(transcript_data, f"{file.filename}.srt")
        
        if os.path.exists(temp_video_path):
            os.remove(temp_video_path)
        if os.path.exists(audio_path):
            os.remove(audio_path)

        return JSONResponse(content={
            "filename": file.filename,
            "status": "success",
            "srt_file": srt_path,
            "data": transcript_data
        })
    except Exception as e:
        if os.path.exists(temp_video_path):
            os.remove(temp_video_path)
        if 'audio_path' in locals() and os.path.exists(audio_path):
            os.remove(audio_path)
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/translate", summary="Phase 2: Standalone Transcript Translation")
async def translate_only(request: TranslationRequest):
    """
    Translates an existing list of transcript segments to a target language.
    """
    try:
        raw_segments = [s.model_dump() for s in request.segments]
        translated = translate_transcript(raw_segments, target_lang=request.target_lang)
        return JSONResponse(content={
            "target_lang": request.target_lang,
            "translated_segments": translated
        })
    except Exception as e:
        raise HTTPException(status_code=500, detail=str(e))


@app.post("/transcribe-and-translate", summary="Phase 1 & 2 Combined: Video to Translated Transcript")
async def process_video_and_translate(
    file: UploadFile = File(...),
    target_lang: str = Query("es", description="Language code (e.g., 'es', 'fr', 'de', 'ja')")
):
    """
    Uploads a video file, transcribes it, translates it, and generates a translated SRT subtitle file.
    """
    if not file.filename.lower().endswith(('.mp4', '.mkv', '.mov', '.avi')):
        raise HTTPException(status_code=400, detail="Invalid file type.")

    temp_video_path = f"temp_{file.filename}"
    try:
        with open(temp_video_path, "wb") as buffer:
            shutil.copyfileobj(file.file, buffer)
            
        audio_path = extract_audio(temp_video_path)
        transcript_data = transcribe_audio(audio_path)
        
        # Translate transcript
        translated_data = translate_transcript(transcript_data, target_lang=target_lang)
        
        # Build SRT formatted list for target language
        translated_srt_input = [
            {"start": item["start"], "end": item["end"], "text": item["translated_text"]}
            for item in translated_data
        ]
        translated_srt_path = generate_srt(translated_srt_input, f"{file.filename}_{target_lang}.srt")

        if os.path.exists(temp_video_path):
            os.remove(temp_video_path)
        if os.path.exists(audio_path):
            os.remove(audio_path)

        return JSONResponse(content={
            "filename": file.filename,
            "target_lang": target_lang,
            "translated_srt_file": translated_srt_path,
            "data": translated_data
        })

    except Exception as e:
        if os.path.exists(temp_video_path):
            os.remove(temp_video_path)
        if 'audio_path' in locals() and os.path.exists(audio_path):
            os.remove(audio_path)
        raise HTTPException(status_code=500, detail=str(e))

if __name__ == "__main__":
    import uvicorn
    uvicorn.run("main:app", host="127.0.0.1", port=8000, reload=True)